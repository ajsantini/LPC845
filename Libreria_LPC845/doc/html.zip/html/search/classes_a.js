var searchData=
[
  ['temperature_5fcounts_5ft',['temperature_counts_t',['../termometro_8c.html#structtemperature__counts__t',1,'']]],
  ['timer_5ft',['timer_t',['../structtimer__t.html',1,'']]]
];
