var searchData=
[
  ['relays_2ec',['relays.c',['../relays_8c.html',1,'']]],
  ['relays_2eh',['relays.h',['../relays_8h.html',1,'']]],
  ['relays_5factivate',['relays_activate',['../relays_8h.html#a67e0d1cb65b31050d361b6f18c91a2c0',1,'relays_activate(uint8_t numero_rele):&#160;relays.c'],['../relays_8c.html#a67e0d1cb65b31050d361b6f18c91a2c0',1,'relays_activate(uint8_t numero_rele):&#160;relays.c']]],
  ['relays_5fcheck',['relays_check',['../relays_8h.html#a30f6586b6c048e336f1aa5fa1290e331',1,'relays_check(void):&#160;relays.c'],['../relays_8c.html#a30f6586b6c048e336f1aa5fa1290e331',1,'relays_check(void):&#160;relays.c']]],
  ['relays_5fdeactivate',['relays_deactivate',['../relays_8h.html#af8ac0b590fa5a5784a939d3351e4bd6e',1,'relays_deactivate(uint8_t numero_rele):&#160;relays.c'],['../relays_8c.html#af8ac0b590fa5a5784a939d3351e4bd6e',1,'relays_deactivate(uint8_t numero_rele):&#160;relays.c']]],
  ['relays_5finit',['relays_init',['../relays_8h.html#ace38a6a87fd0b61ead944d25547e243a',1,'relays_init(void):&#160;relays.c'],['../relays_8c.html#ace38a6a87fd0b61ead944d25547e243a',1,'relays_init(void):&#160;relays.c']]],
  ['relays_5ftoggle',['relays_toggle',['../relays_8h.html#a384e2e7af88b980784bdda984c9f834f',1,'relays_toggle(uint8_t numero_rele):&#160;relays.c'],['../relays_8c.html#a384e2e7af88b980784bdda984c9f834f',1,'relays_toggle(uint8_t numero_rele):&#160;relays.c']]],
  ['result',['result',['../group__ADC.html#a0971e3d432b7f1f283620cab047a7275',1,'hal_adc_sequence_result_t']]]
];
