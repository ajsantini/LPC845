var searchData=
[
  ['result',['result',['../group__ADC.html#a0971e3d432b7f1f283620cab047a7275',1,'hal_adc_sequence_result_t']]]
];
