var searchData=
[
  ['wkt_5fcount_5freg_5ft',['WKT_COUNT_reg_t',['../HRI__WKT_8h.html#structWKT__COUNT__reg__t',1,'']]],
  ['wkt_5fctrl_5freg_5ft',['WKT_CTRL_reg_t',['../HRI__WKT_8h.html#structWKT__CTRL__reg__t',1,'']]],
  ['wkt_5fper_5ft',['WKT_per_t',['../HRI__WKT_8h.html#structWKT__per__t',1,'']]]
];
