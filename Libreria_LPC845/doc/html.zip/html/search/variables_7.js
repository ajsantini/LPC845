var searchData=
[
  ['low_5fpriority',['low_priority',['../structhal__adc__sequence__config__t.html#a1dc8fcb4920ed109389a6391e8c1c9ef',1,'hal_adc_sequence_config_t']]],
  ['lowprio',['LOWPRIO',['../HRI__ADC_8h.html#ac32d66a04cd04d1fc9188eebd52dcbbb',1,'ADC_SEQ_CTRL_reg_t']]],
  ['lpwrmode',['LPWRMODE',['../HRI__ADC_8h.html#ac7ad855f464226b05393c01215077633',1,'ADC_CTRL_reg_t']]]
];
