var searchData=
[
  ['adc_5fchan_5fthrsel_5freg_5ft',['ADC_CHAN_THRSEL_reg_t',['../HRI__ADC_8h.html#structADC__CHAN__THRSEL__reg__t',1,'']]],
  ['adc_5fchannel_5fdata_5ft',['ADC_channel_data_t',['../HPL__ADC_8h.html#structADC__channel__data__t',1,'']]],
  ['adc_5fctrl_5freg_5ft',['ADC_CTRL_reg_t',['../HRI__ADC_8h.html#structADC__CTRL__reg__t',1,'']]],
  ['adc_5fdat_5freg_5ft',['ADC_DAT_reg_t',['../HRI__ADC_8h.html#structADC__DAT__reg__t',1,'']]],
  ['adc_5fflags_5freg_5ft',['ADC_FLAGS_reg_t',['../HRI__ADC_8h.html#structADC__FLAGS__reg__t',1,'']]],
  ['adc_5fglobal_5fdata_5ft',['ADC_global_data_t',['../HPL__ADC_8h.html#structADC__global__data__t',1,'']]],
  ['adc_5finten_5freg_5ft',['ADC_INTEN_reg_t',['../HRI__ADC_8h.html#structADC__INTEN__reg__t',1,'']]],
  ['adc_5fper_5ft',['ADC_per_t',['../HRI__ADC_8h.html#structADC__per__t',1,'']]],
  ['adc_5fseq_5fctrl_5freg_5ft',['ADC_SEQ_CTRL_reg_t',['../HRI__ADC_8h.html#structADC__SEQ__CTRL__reg__t',1,'']]],
  ['adc_5fseq_5fgdat_5freg_5ft',['ADC_SEQ_GDAT_reg_t',['../HRI__ADC_8h.html#structADC__SEQ__GDAT__reg__t',1,'']]],
  ['adc_5fthr_5fhigh_5freg_5ft',['ADC_THR_HIGH_reg_t',['../HRI__ADC_8h.html#structADC__THR__HIGH__reg__t',1,'']]],
  ['adc_5fthr_5flow_5freg_5ft',['ADC_THR_LOW_reg_t',['../HRI__ADC_8h.html#structADC__THR__LOW__reg__t',1,'']]],
  ['adc_5ftrm_5freg_5ft',['ADC_TRM_reg_t',['../HRI__ADC_8h.html#structADC__TRM__reg__t',1,'']]]
];
