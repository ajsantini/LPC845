var searchData=
[
  ['callback',['callback',['../structhal__adc__sequence__config__t.html#a42710517a48ebba1b95e66e9f005cf7d',1,'hal_adc_sequence_config_t']]],
  ['calmode',['CALMODE',['../HRI__ADC_8h.html#add69b74ced19a7667ec73b713dc9dfae',1,'ADC_CTRL_reg_t']]],
  ['capture_5fcallbacks',['capture_callbacks',['../HAL__CTIMER_8c.html#a4a8c3010c0359d5ea94a0349b3a9fc1b',1,'HAL_CTIMER.c']]],
  ['channel',['channel',['../group__ADC.html#a14b46f8d352b49c5be28cad8aafff2ba',1,'hal_adc_sequence_result_t']]],
  ['channels',['CHANNELS',['../HRI__ADC_8h.html#ab6b7040c8266731e8b3759ccb41b181d',1,'ADC_SEQ_CTRL_reg_t::CHANNELS()'],['../structhal__adc__sequence__config__t.html#acebe3f0fdc69a72787ddd6b19870641b',1,'hal_adc_sequence_config_t::channels()']]],
  ['clkdiv',['CLKDIV',['../HRI__ADC_8h.html#aa11dafc1481a6f613e960f2a7a83db4c',1,'ADC_CTRL_reg_t']]],
  ['clock_5fdiv',['clock_div',['../structhal__ctimer__pwm__config__t.html#adba76882bdceba1a0d87c31457c5e491',1,'hal_ctimer_pwm_config_t']]],
  ['conversion_5ftable',['conversion_table',['../termometro_8c.html#aba4b392878c7b634ffe3ca9e64ed6fd1',1,'termometro.c']]],
  ['counts',['counts',['../termometro_8c.html#af89eac0f00fd4960f509a5afabb62939',1,'temperature_counts_t']]],
  ['ctimer',['CTIMER',['../HPL__CTIMER_8h.html#a8150dcb6b90800d1dfe8669e1f21f549',1,'CTIMER():&#160;HPL_CTIMER.c'],['../HPL__CTIMER_8c.html#a8150dcb6b90800d1dfe8669e1f21f549',1,'CTIMER():&#160;HPL_CTIMER.c']]],
  ['current_5fcrystal_5ffreq',['current_crystal_freq',['../HAL__SYSCON_8c.html#ac48d70bca4ef65be38977958d1598039',1,'HAL_SYSCON.c']]],
  ['current_5ffrg_5ffreq',['current_frg_freq',['../HAL__SYSCON_8c.html#a9d4532ef5b1662c09cb5e8ab073a3f11',1,'HAL_SYSCON.c']]],
  ['current_5ffro_5ffreq',['current_fro_freq',['../HAL__SYSCON_8c.html#aad3fec23f8f4711b102b23fa07e290e9',1,'HAL_SYSCON.c']]],
  ['current_5fmain_5ffreq',['current_main_freq',['../HAL__SYSCON_8c.html#a3aac493f3f270a17ed65a333b4244f4e',1,'HAL_SYSCON.c']]],
  ['current_5fpll_5ffreq',['current_pll_freq',['../HAL__SYSCON_8c.html#a2bdaacaa8a1115bb2aa049754ad27ecd',1,'HAL_SYSCON.c']]]
];
