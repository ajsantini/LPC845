var searchData=
[
  ['mrt_5fclear_5firq_5fflag',['MRT_clear_irq_flag',['../HPL__MRT_8h.html#a0c850363425d78f9d5d7521ab70d0c4f',1,'HPL_MRT.h']]],
  ['mrt_5fconfig_5fmode',['MRT_config_mode',['../HPL__MRT_8h.html#a41688adbcd5743919a123f2c6de108cd',1,'HPL_MRT.h']]],
  ['mrt_5fget_5fcurrent_5fvalue',['MRT_get_current_value',['../HPL__MRT_8h.html#a08b75e369a8bc8a498ec27b8903ffa89',1,'HPL_MRT.h']]],
  ['mrt_5fget_5fidle_5fchannel',['MRT_get_idle_channel',['../HPL__MRT_8h.html#ade5ba4007e452503ef2c39c22b28613b',1,'HPL_MRT.h']]],
  ['mrt_5fget_5firq_5fflag',['MRT_get_irq_flag',['../HPL__MRT_8h.html#afcbf27c3ca99f0b0f8094ba6dea4d5d9',1,'HPL_MRT.h']]],
  ['mrt_5fset_5finterval',['MRT_set_interval',['../HPL__MRT_8h.html#a63c0887416689930fa0b2440a0d36afa',1,'HPL_MRT.h']]],
  ['mrt_5fset_5finterval_5fand_5fstop_5ftimer',['MRT_set_interval_and_stop_timer',['../HPL__MRT_8h.html#a1368fc13d7cd7f4167738281380d56ac',1,'HPL_MRT.h']]]
];
