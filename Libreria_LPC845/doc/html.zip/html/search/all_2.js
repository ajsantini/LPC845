var searchData=
[
  ['burst',['BURST',['../HRI__ADC_8h.html#a6b54386ca3acc9f6976d71116e0eb1ae',1,'ADC_SEQ_CTRL_reg_t']]]
];
