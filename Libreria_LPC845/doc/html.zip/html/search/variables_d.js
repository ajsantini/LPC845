var searchData=
[
  ['temperature',['temperature',['../termometro_8c.html#a76db55b29a9bebd5a0e343e88d20825c',1,'temperature_counts_t']]],
  ['trigger',['TRIGGER',['../HRI__ADC_8h.html#a084459dd951ce06483ea9fb3cb1d8c9c',1,'ADC_SEQ_CTRL_reg_t::TRIGGER()'],['../structhal__adc__sequence__config__t.html#a6bcb45974cab7522fa8fddd79fa7f1e1',1,'hal_adc_sequence_config_t::trigger()']]],
  ['trigger_5fpol',['trigger_pol',['../structhal__adc__sequence__config__t.html#a0e3bc5f0a78cf105554a67af8f34d383',1,'hal_adc_sequence_config_t']]],
  ['trigpol',['TRIGPOL',['../HRI__ADC_8h.html#a650a87293bd0fae1cae6f3516d6c8b2a',1,'ADC_SEQ_CTRL_reg_t']]]
];
