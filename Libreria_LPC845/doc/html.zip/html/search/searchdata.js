var indexSectionsWithContent =
{
  0: "_abcdghilmnprstuw",
  1: "acdghimnpstuw",
  2: "dhilrt",
  3: "acdghilmnprstuw",
  4: "_abcdgilmnprstuw",
  5: "h",
  6: "h",
  7: "aps",
  8: "a",
  9: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Estructuras de Datos",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "Enumeraciones",
  6: "Valores de enumeraciones",
  7: "defines",
  8: "Grupos",
  9: "Páginas"
};

